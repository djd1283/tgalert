from setuptools import setup
setup(name='tgalert', version=0.1)
